# image_processing_Pedro_HCDN

Description. 
O pacote image_processing_Pedro_HCDN é usado para:
	Processos:
	- Corresponder histogram
	- Similaridade estrutural
	- Redimensionar imagem
	Utils:
	- read_image
	- save_image
	- plot_image
	- plot_result
	- plot_histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing_Pedro_HCDN
```

## Usage

```python
from package_name.module1_name import file1_name
file1_name.my_function()
```

## Author
Pedro Henrique Chagas do Nascimento

## License
[MIT](https://choosealicense.com/licenses/mit/)